from sirope.oid import OID
from sirope.sirope_main import Sirope
